README

Akshara Sundararajan, 404731846
Rubia Liu, 804796911

Relevant information:
- The output of the query is displayed below
- No input sanitization, since it is not mentioned in the spec
